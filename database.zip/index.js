const express = require('express')

const expressEdge = require('express-edge')

const mongoose = require('mongoose')

const app = new express()

const bodyParser = require('body-parser')

const fileUpload = require('express-fileupload')

const createPostController = require('./controllers/createPost')

const homePageController = require('./controllers/homePage')

const storePostController = require('./controllers/storePost')

const getPostController = require('./controllers/getPost')

const storePost = require('./middleware/storePost')

const createUserController = require('./controllers/createUser')

const storeUserController = require('./controllers/storeUser')

const loginController = require('./controllers/login')

const loginUserController = require('./controllers/loginUser')

mongoose.connect('mongodb://localhost/node-js-blog', { useNewUrlParser: true }).then(() => {
    console.log("Connected to Database");
}).catch((err) => {
    console.log("Not Connected to Database ERROR! ", err);
});

app.use(fileUpload())

app.use(express.static('public'))

app.use(expressEdge)

app.set('views',`${__dirname}/views`)

app.use(bodyParser.json())

app.use(bodyParser.urlencoded({ extended: true }))

app.use('/posts/store', storePost)

app.get('/', homePageController)

app.get('/auth/login', loginController)

app.post('/users/login', loginUserController)

app.get('/auth/register', createUserController)

app.post('/users/register', storeUserController)

app.get('/post/:id', getPostController)

app.get('/posts/new', createPostController);

app.post('/posts/store', storePostController)

app.listen(4000,()=>{
    console.log('App listening on port 4000')
})