const User = require('../database/models/User')

module.exports = (req, res) => {

    const { email, password } = req.body;

    User.findOne({email}, (error,user) => {

        if(user) {
            if(password === user.password) {
                
                res.redirect('/')

            }
            else {

                res.redirect('/auth/login')

            }
        }
        else {

            return res.redirect('/auth/login')
        }
    })
    // try to find the user

    // compare username and password

    // if user and password is correct, then login user.

    // else

    // redirect user back.
    res.redirect('/')
}