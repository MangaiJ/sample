module.exports = (req, res) => {
    
    res.render('create');

};