nodemon
Any time we update the file will restart the server. This is only for development purpose.

Edge templating engine:

for create the template as our wish

MongoDB:
Its starts the information in the form of document.

MongoDB - Contains one or more collections
collections - Contains different types of document(object)
document - key value pair list or array or nested document.

database Contains many collections each collection Contains many document, each document Contains many fields.
 robomongo - Its help us to see our data in our database

 mongoose - is a package manager to help us to interact with mongodb

 mongoose.connect('mongodb://localhost/node-js-blog')

 mongodb - is server
 localhost - our localserver
 node-js-blog - db name we are going to connect

 when we connect the server mongodb will automatically create the node-js-blog db for us

 production: we need username and password  for connection
 
 models - its a function or objects that represent collections in our database.

 schema - represent how we are going to structure our collections (collections represents entity in application)

 body-parser:
 Its going to pass the data from my browser and give us in a understandable format in a node js app.

app.use(bodyParser.json()) - our application connect with the json from browser

app.use(bodyParser.urlencoded({ extended: true })) - Able to pass data from browser and understandable by the node js.

express-fileupload - Module used to upload the image.

encType="multipart/form-data"  -  This indicates that form contains multimedia and the form going to send the multimedia data to server.

middleware - Is a function express executes before actually handling the request coming from the browser

next() - This will tell express to proceed next request.

Why middleware = Before express handle the request from the browser 

app.use('/posts/store',validateCreatePostMiddleware) - middleware should call for particular express.

